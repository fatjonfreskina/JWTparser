package com.mycompany.app;

import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Logger;

import javax.crypto.Mac;
import org.json.JSONObject;

public class JWTparser {

    private JSONObject header;
    private JSONObject payload;
    private String signature;
    private boolean isExpired;
    private String headerAndPayloadHashed;
    private boolean isValid;

    public JWTparser(String token) {
        // split into 3 parts with . delimiter
        String[] parts = token.split("\\.");

        this.header = new JSONObject(decode(parts[0]));
        this.payload = new JSONObject(decode(parts[1]));
        this.signature = decode(parts[2]);
        //this.isExpired = !(payload.getLong("exp") > (System.currentTimeMillis() / 1000));
        this.headerAndPayloadHashed = hmacSha256(parts[0] +"."+ parts[1], "your-256-bit-secret");
        this.isValid = this.signature.equals(this.headerAndPayloadHashed);
    }

    private static String decode(String encodedString) {
        return new String(Base64.getUrlDecoder().decode(encodedString));
    }

    private String hmacSha256(String data, String secret) {
        try {

            byte[] hash = secret.getBytes(StandardCharsets.UTF_8);
            Mac sha256Hmac = Mac.getInstance("HmacSHA256");
            SecretKeySpec secretKey = new SecretKeySpec(hash, "HmacSHA256");
            sha256Hmac.init(secretKey);
            byte[] signedBytes = sha256Hmac.doFinal(data.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(signedBytes);

        } catch (NoSuchAlgorithmException | InvalidKeyException ex) {
            Logger.getLogger(JWTparser.class.getName());
            return null;
        }
    }

    public JSONObject getHeader() {
        return header;
    }

    public JSONObject getPayload() {
        return payload;
    }

    public String getSignature() {
        return signature;
    }

    public boolean isExpired() {
        return isExpired;
    }

    public String getHeaderAndPayloadHashed() {
        return headerAndPayloadHashed;
    }

    public boolean isValid() {
        return isValid;
    }

}
