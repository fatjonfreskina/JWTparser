package com.mycompany.app;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        String example = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.cThIIoDvwdueQB468K5xDc5633seEFoqwxjF_xSJyQQ";
        JWTparser test = new JWTparser(example);
        System.out.println(test.getHeader());
        System.out.println(test.getPayload());
        long userID = test.getPayload().getLong("sub");
        System.out.println("User id is: " + userID);
        System.out.println(test.isExpired());
        System.out.println(test.isValid());
    }
}
